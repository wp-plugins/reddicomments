=== ReddiComments ===
Contributors: almithani
Tags: reddit, comments
License: GPL 2.0
License URI: http://choosealicense.com/licenses/gpl-2.0/

Allows you to embed Reddit comments into your posts.  